from setuptools import setup, find_packages

name = 'template_project'


setup(name=name,
      version='0.1',
      packages=find_packages(),
      install_requires=['pytest'])
