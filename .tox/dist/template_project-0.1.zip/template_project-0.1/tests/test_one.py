from one.mod_one import my_var as v


def test_module_one():
    assert v
